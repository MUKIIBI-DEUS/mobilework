package com.example.litbook;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {
    private List<BookModel> bookModelList;
    private OnItemClickListener listener;

    public MyAdapter(List<BookModel> bookModelList, OnItemClickListener listener) {
        this.bookModelList = bookModelList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.book_item_view, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        final BookModel book = bookModelList.get(position);

        holder.bookImage.setImageResource(book.getBookImage());
        holder.bookGenre.setText(book.getBookGenre());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onItemClick(book.getBookImage(), book.getBookGenre());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return bookModelList.size();
    }

    // Interface for item click listener
    public interface OnItemClickListener {
        void onItemClick(int bookImage, String bookGenre);
    }
}
