package com.example.litbook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class romanceBooks extends AppCompatActivity implements MyAdapter.OnItemClickListener {
    private List<BookModel> bookList;
    private RecyclerView recyclerView;
    private MyAdapter adapter;
    private ImageView backToMainPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_romance_books);



        // Initialize views
        recyclerView = findViewById(R.id.recyclerView1);
        backToMainPage = findViewById(R.id.logout);

        // Set layout manager for RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));







        // Sample data for the RecyclerView
        bookList = new ArrayList<>();

        // Adding initial data manually to the list
        bookList.add(new BookModel(R.mipmap.book6, "Love theoritically"));
        bookList.add(new BookModel(R.mipmap.amancalledlove, "A man called Love"));
        bookList.add(new BookModel(R.mipmap.alwaysbemyduchess, "Always be my duchess"));





        // Create and set adapter
        adapter = new MyAdapter(bookList, this); // Passing 'this' as the listener
        recyclerView.setAdapter(adapter);

    }

    // Implement onItemClick method from MyAdapter.OnItemClickListener interface
    @Override
    public void onItemClick(int bookImage, String genre) {
        // Print out book and genre
        Log.d("Clicked item", "Book: " + bookImage + ", Genre: " + genre);

        //load book on click
        if(genre.equals("Love theoritically")){
            Intent loveThoeritically=new Intent(romanceBooks.this, loveTheoritically.class);
            startActivity(loveThoeritically);

        } else if (genre.equals("A man called Love")){
            Intent amancalledLove=new Intent(romanceBooks.this, amancalledLove.class);
            startActivity(amancalledLove);

        } else if (genre.equals("Always be my duchess")){
            Intent alwaysbemyduchess=new Intent(romanceBooks.this, alwaysbemyduchess.class);
            startActivity(alwaysbemyduchess);

        }

    }
}