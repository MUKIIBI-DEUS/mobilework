package com.example.litbook;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder {
    public ImageView bookImage;
    public TextView bookGenre;

    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        bookImage = itemView.findViewById(R.id.book_image);
        bookGenre = itemView.findViewById(R.id.book_genre);
    }
}

