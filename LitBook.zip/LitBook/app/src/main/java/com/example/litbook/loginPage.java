package com.example.litbook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class loginPage extends AppCompatActivity {
    private ImageView backToMainPage;
    private EditText userName;//userName editText in the loginPage
    private EditText password;//password editText in the loginPage

    private Button loginButton;//loginButton

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);


        //head back  to the main page
        backToMainPage=findViewById(R.id.backToMainPage);
        backToMainPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loginPage=new Intent(loginPage.this,com.example.litbook.MainActivity.class);
                startActivity(loginPage);
            }
        });




        //user login functionality
        userName=findViewById(R.id.userName);
        password=findViewById(R.id.password);
        loginButton=findViewById(R.id.loginButton);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //final loginFunctionality==========================
                //fetch userName and password input
                String userNameInput=String.valueOf(userName.getText());
                String passwordInput=String.valueOf(password.getText());

                //verify user credentials to open homepage
                if(userNameInput.equals("rita") && passwordInput.equals("good123")){

                    Intent homePage=new Intent(loginPage.this,com.example.litbook.homePage.class);
                    startActivity(homePage);//load the home page if right credntials

                }else{
                    Toast.makeText(loginPage.this, "Worng Credentials", Toast.LENGTH_SHORT).show();
                }

            }
        });







    }
}