package com.example.litbook;

public class BookModel {



    private int bookImage;



    private String bookGenre;



//Constructor
    public BookModel(int bookImage, String bookGenre) {
        this.bookImage = bookImage;
        this.bookGenre = bookGenre;
    }

//GETTERS======================================================
    public int getBookImage() {
        return bookImage;
    }

    public String getBookGenre() {
        return bookGenre;
    }


//SETTERS
    public void setBookImage(int bookImage) {
        this.bookImage = bookImage;
    }

    public void setBookGenre(String bookGenre) {
        this.bookGenre = bookGenre;
    }









}
