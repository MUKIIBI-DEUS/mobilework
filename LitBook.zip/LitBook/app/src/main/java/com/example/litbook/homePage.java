package com.example.litbook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.List;

public class homePage extends AppCompatActivity implements MyAdapter.OnItemClickListener {
    private List<BookModel> bookList;
    private RecyclerView recyclerView;
    private MyAdapter adapter;

    // Route BUTTONS
    private Button recommendedBooks;
    private Button popularBooks;
    private Button latestBooks;

    private Button genre;
    private ImageView backToMainPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        // Initialize views
        recyclerView = findViewById(R.id.recyclerView1);
        backToMainPage = findViewById(R.id.logout);
        recommendedBooks = findViewById(R.id.recommended);
        popularBooks = findViewById(R.id.popular);
        genre=findViewById(R.id.genre);
        latestBooks = findViewById(R.id.latest);

        // Set layout manager for RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Sample data for the RecyclerView
        bookList = new ArrayList<>();

        // Adding initial data manually to the list
        bookList.add(new BookModel(R.mipmap.book3, "Romance"));
        bookList.add(new BookModel(R.mipmap.book5, "Fiction"));
        bookList.add(new BookModel(R.mipmap.book9, "Non-fiction"));
        bookList.add(new BookModel(R.mipmap.book7, "Mystery"));

        // Create and set adapter
        adapter = new MyAdapter(bookList, this); // Passing 'this' as the listener
        recyclerView.setAdapter(adapter);

        // Handle back to main page button click
        backToMainPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loginPage = new Intent(homePage.this, com.example.litbook.MainActivity.class);
                startActivity(loginPage);
            }
        });

        //favorite books
        recommendedBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bookList.clear();
                // Adding initial data manually to the list
                bookList.add(new BookModel(R.mipmap.book6, "Love theoritically"));
                bookList.add(new BookModel(R.mipmap.amancalledlove, "A man called Love"));
                bookList.add(new BookModel(R.mipmap.alwaysbemyduchess, "Always be my duchess"));
                adapter.notifyDataSetChanged();

            }
        });

        // Button click listeners to change the content of RecyclerView
        popularBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bookList.clear();
                bookList.add(new BookModel(R.mipmap.book6, "Love theoritically"));
                bookList.add(new BookModel(R.mipmap.amancalledlove, "A man called Love"));
                adapter.notifyDataSetChanged();
            }
        });

        latestBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bookList.clear();
                bookList.add(new BookModel(R.mipmap.book6, "Love theoritically"));
                adapter.notifyDataSetChanged();
            }
        });


        //genre
        genre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bookList.clear();
                // Adding initial data manually to the list
                bookList.add(new BookModel(R.mipmap.book2, "Romance"));
                bookList.add(new BookModel(R.mipmap.book2, "Fiction"));
                bookList.add(new BookModel(R.mipmap.book2, "Non-fiction"));
                bookList.add(new BookModel(R.mipmap.book2, "Mystery"));
                adapter.notifyDataSetChanged();
            }
        });




    }

    // Implement onItemClick method from MyAdapter.OnItemClickListener interface
    @Override
    public void onItemClick(int bookImage, String genre) {
        // Print out book and genre
        Log.d("Clicked item", "Book: " + bookImage + ", Genre: " + genre);

        //logRomantic books if selected pad is for romance
        if(genre.equals("Romance")){
            Intent loadRomance=new Intent(homePage.this, romanceBooks.class);
            startActivity(loadRomance);

        } else if (genre.equals("Fiction")){
            Intent loadRomance=new Intent(homePage.this, romanceBooks.class);
            startActivity(loadRomance);

        } else if (genre.equals("Non-fiction")){
            Intent loadRomance=new Intent(homePage.this, romanceBooks.class);
            startActivity(loadRomance);

        } else if (genre.equals("Mystery")){
            Intent loadRomance=new Intent(homePage.this, romanceBooks.class);
            startActivity(loadRomance);

        } else if (genre.equals("Romance")){
            Intent loadRomance=new Intent(homePage.this, romanceBooks.class);
            startActivity(loadRomance);

        }



        //BOOKS FAVORITE BOOKS
        //load book on click
        if(genre.equals("Love theoritically")){
            Intent loveThoeritically=new Intent(homePage.this, loveTheoritically.class);
            startActivity(loveThoeritically);

        } else if (genre.equals("A man called Love")){
            Intent amancalledLove=new Intent(homePage.this, amancalledLove.class);
            startActivity(amancalledLove);

        } else if (genre.equals("Always be my duchess")){
            Intent alwaysbemyduchess=new Intent(homePage.this, alwaysbemyduchess.class);
            startActivity(alwaysbemyduchess);

        }
    }
}
